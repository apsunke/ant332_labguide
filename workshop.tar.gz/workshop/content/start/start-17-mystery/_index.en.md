+++
title = "Mystery hunt exercise"
date = 2019-11-26T20:55:15-08:00
weight = 26
chapter = true
+++

Great job setting the environment! You now have logs and metrics flowing in Amazon ES and you can visualize all of this data in Kibana.

The last portion of this workshop is called **Mystery Hunt**. We'll ask you to run mystery scripts that make changes to your environment, you'll then need to investigate and find root cause. We'll have hints along the way to guide you.

Kibana is all you need for this exercise, it has all the data including visualizations.
