+++
title = "Let the lab begin!"
date = 2019-11-26T20:14:20-08:00
weight = 10
chapter = true
pre = "<b>6. </b>"
+++

In order to save time, we have already pre-deployed the environment for you. You account will have the following resources
