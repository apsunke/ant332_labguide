+++
title = "Configure Kibana for apache index"
date = 2019-11-26T19:44:40-08:00
weight = 3
pre = "<b>3. </b>"
+++

Repeat the previous step again to create an index pattern for **apache-** index. Click this deep link to open Kibana in your browser and follow the steps below -
http://localhost:9200/_plugin/kibana

Click **Management tab** -> Click **Index Patterns** -> Click **Create Index Pattern** -> Type ***apache-**** in input box -> Choose ***@timestamp*** from drop down-> Click **Create Index Pattern**

![alt text](https://ant332.s3-us-west-2.amazonaws.com/ant332-lab-guide-artifacts/apache-index.png)
