+++
title = "Configure Kibana for redis index"
date = 2019-11-26T19:44:40-08:00
weight = 2
pre = "<b>2. </b>"
+++

Repeat the previous step to create an index pattern for **redis-** index. Click this deep link to open Kibana in your browser and follow the steps below - http://localhost:9200/_plugin/kibana

Click **Management tab** -> Click **Index Patterns** -> Click **Create Index Pattern** -> Type ***redis-**** in input box -> Choose ***@timestamp*** from drop down-> Click **Create Index Pattern**

![alt text](https://ant332.s3-us-west-2.amazonaws.com/ant332-lab-guide-artifacts/redis-index.png)
